# ECH Tunnel Client (Rust)

基于 Rustls 实现的 ECH 隧道客户端，支持 TLS 指纹随机化。

## 功能特性

- ✅ **ECH (Encrypted Client Hello)** - 加密 SNI，保护隐私
- ✅ **TLS 指纹随机化** - 规避 JA3/JA4 检测（使用 jarustls）
- ✅ **双协议支持** - SOCKS5 和 HTTP CONNECT
- ✅ **WebSocket 传输** - 基于 WebSocket 的隧道协议
- ✅ **DoH 查询** - 自动获取 ECH 配置
- ✅ **高性能** - 异步 I/O，零拷贝转发

## 编译

```bash
cd client-rs
cargo build --release
```

编译后的可执行文件位于 `target/release/ech-client-rs`

## 使用方法

### 基本用法

```bash
./ech-client-rs \
  -l 127.0.0.1:1080 \
  -f your-worker.workers.dev:443 \
  -t your-token
```

### 完整参数

```bash
./ech-client-rs \
  --listen 127.0.0.1:1080 \           # 本地监听地址
  --server worker.dev:443 \            # 服务端地址
  --token your-token \                 # 身份验证令牌
  --ech-domain cloudflare-ech.com \    # ECH 查询域名
  --dns-server dns.alidns.com/dns-query \ # DoH 服务器
  --randomize-fingerprint true         # 启用指纹随机化（默认）
```

### 禁用 ECH（Fallback 模式）

```bash
./ech-client-rs \
  -l 127.0.0.1:1080 \
  -f your-worker.workers.dev:443 \
  -t your-token \
  --fallback
```

## 参数说明

| 参数 | 短参数 | 默认值 | 说明 |
|------|--------|--------|------|
| `--listen` | `-l` | `127.0.0.1:30000` | 本地代理监听地址 |
| `--server` | `-f` | - | 服务端地址（必须） |
| `--server-ip` | - | - | 指定服务端 IP（绕过 DNS） |
| `--token` | `-t` | - | 身份验证令牌 |
| `--dns-server` | - | `dns.alidns.com/dns-query` | DoH 服务器 |
| `--ech-domain` | - | `cloudflare-ech.com` | ECH 查询域名 |
| `--fallback` | - | `false` | 禁用 ECH（普通 TLS） |
| `--randomize-fingerprint` | - | `true` | 启用指纹随机化 |
| `--num-conns` | `-n` | `1` | 并发连接数 |

## 配置浏览器

### Chrome/Edge

1. 打开设置 → 高级 → 系统
2. 代理设置 → 手动代理
3. SOCKS5 代理：`127.0.0.1:1080`

### Firefox

1. 设置 → 网络设置
2. 手动代理配置
3. SOCKS5 主机：`127.0.0.1`，端口：`1080`
4. 勾选"使用 SOCKS v5 时代理 DNS"

## 技术细节

### TLS 指纹随机化

本客户端使用的 `jarustls` 库实现了以下随机化策略：

1. **Cipher Suites 随机化**
   - 45% 概率交换前两个套件
   - 45% 概率保持原顺序
   - 10% 概率将 AES_256 移到首位

2. **Padding 扩展**
   - 70% 概率添加
   - 80-300 字节随机长度

3. **Extension 顺序随机化**
   - 自动随机化扩展顺序
   - 保护协议约束（PSK 最后，ECH 倒数第二）

### ECH 工作流程

1. 通过 DoH 查询 HTTPS 记录获取 ECH 配置
2. 解析 ECH 配置参数
3. 在 TLS ClientHello 中加密 SNI
4. 建立加密的 TLS 连接

## 对比 Go 版本

| 特性 | Rust 版本 | Go 版本 |
|------|-----------|---------|
| TLS 库 | rustls (指纹随机化) | Go crypto/tls |
| ECH 支持 | ✅ | ✅ |
| 指纹随机化 | ✅ 内置 | ❌ 无 |
| WebSocket | ✅ | ✅ |
| gRPC | ⏳ 待实现 | ✅ |
| TUN 模式 | ⏳ 待实现 | ✅ (仅 Windows) |
| 性能 | 更快 | 快 |
| 内存占用 | 更低 | 低 |

## 开发计划

- [ ] gRPC 传输支持
- [ ] TUN 模式（跨平台）
- [ ] 连接池优化
- [ ] 自动重连机制
- [ ] 配置文件支持
- [ ] GUI 界面

## 故障排除

### 连接失败

1. 检查服务端地址和端口是否正确
2. 检查令牌是否正确
3. 尝试使用 `--fallback` 禁用 ECH
4. 检查防火墙设置

### ECH 配置获取失败

1. 检查 DoH 服务器是否可访问
2. 尝试更换 DNS 服务器：
   ```bash
   --dns-server dns.google/dns-query
   --dns-server 1.1.1.1/dns-query
   ```
3. 检查 ECH 域名是否正确

### 性能问题

1. 增加并发连接数：`-n 4`
2. 检查网络延迟
3. 使用 `--server-ip` 指定 IP 绕过 DNS

## 许可证

与 rustls 相同：Apache-2.0 / ISC / MIT

## 致谢

- [rustls](https://github.com/rustls/rustls) - 现代 TLS 库
- [tokio](https://tokio.rs) - 异步运行时
- [tungstenite](https://github.com/snapview/tungstenite-rs) - WebSocket 实现
