/// 简单测试示例
/// 
/// 用法：
/// cargo run --example simple_test

use tracing::{info};

#[tokio::main]
async fn main() {
    tracing_subscriber::fmt()
        .with_max_level(tracing::Level::INFO)
        .init();

    info!("========================================");
    info!("ECH Client Rust - 简单测试");
    info!("========================================");
    info!("");
    info!("✅ 异步运行时初始化成功");
    info!("✅ 日志系统初始化成功");
    info!("");
    info!("要运行完整客户端，请使用:");
    info!("  cargo run -- -l 127.0.0.1:1080 -f your-server:443 -t your-token");
    info!("");
    info!("或者使用编译后的程序:");
    info!("  target/release/ech-client-rs -l 127.0.0.1:1080 -f your-server:443 -t your-token");
}
