@echo off
echo ========================================
echo 编译 ECH Tunnel Client (Rust)
echo ========================================
echo.

echo [1/3] 检查 Rust 环境...
where cargo >nul 2>&1
if errorlevel 1 (
    echo ❌ 错误: 未找到 Cargo
    echo 请先安装 Rust: https://rustup.rs/
    pause
    exit /b 1
)

echo ✅ Rust 环境正常
echo.

echo [2/3] 开始编译...
cargo build --release
if errorlevel 1 (
    echo ❌ 编译失败
    pause
    exit /b 1
)

echo.
echo [3/3] 编译完成
echo.
echo ========================================
echo ✅ 编译成功！
echo ========================================
echo.
echo 可执行文件位置:
echo   target\release\ech-client-rs.exe
echo.
echo 运行示例:
echo   target\release\ech-client-rs.exe -l 127.0.0.1:1080 -f your-worker.workers.dev:443 -t your-token
echo.
pause
