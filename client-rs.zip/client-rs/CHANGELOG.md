# Changelog

## [0.1.0] - 2025-12-20

### 新增功能

- ✅ 基于 rustls 的 TLS 连接（带指纹随机化）
- ✅ ECH (Encrypted Client Hello) 支持
- ✅ DoH (DNS over HTTPS) 查询 ECH 配置
- ✅ SOCKS5 代理协议支持
- ✅ HTTP CONNECT 代理协议支持
- ✅ WebSocket 传输层
- ✅ 异步 I/O 性能优化

### 与 Go 版本对比

**已实现：**
- ✅ WebSocket + ECH 传输
- ✅ TLS 指纹随机化（Go 版本无此功能）
- ✅ SOCKS5 代理
- ✅ HTTP CONNECT 代理
- ✅ DoH 查询

**待实现：**
- ⏳ gRPC 传输
- ⏳ TUN 模式
- ⏳ 连接池
- ⏳ 系统代理设置

### 技术栈

- Rust 1.83+
- Tokio (异步运行时)
- Rustls + jarustls (TLS + 指纹随机化)
- Tokio-tungstenite (WebSocket)
- Reqwest (HTTP 客户端)

### 性能特点

- 内存占用更低（相比 Go 版本）
- CPU 使用率更低
- 更快的启动速度
- 更小的可执行文件（使用 LTO + strip）
