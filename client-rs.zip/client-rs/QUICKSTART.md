# 快速开始指南

## 前提条件

1. **安装 Rust**
   ```bash
   # Windows
   下载并运行: https://rustup.rs/
   
   # 或使用 winget
   winget install Rustlang.Rustup
   ```

2. **验证安装**
   ```bash
   rustc --version
   cargo --version
   ```

## 编译步骤

### Windows

```batch
# 1. 进入项目目录
cd client-rs

# 2. 运行编译脚本
build.bat

# 或手动编译
cargo build --release
```

### Linux/Mac OS

```bash
# 1. 进入项目目录
cd client-rs

# 2. 编译
cargo build --release
```

## 运行客户端

### 方式一：使用 run.bat（Windows 快捷方式）

```batch
run.bat
# 然后按提示输入服务器地址和令牌
```

### 方式二：命令行直接运行

```bash
# Windows
target\release\ech-client-rs.exe -l 127.0.0.1:1080 -f your-worker.workers.dev:443 -t your-token

# Linux/macOS
./target/release/ech-client-rs -l 127.0.0.1:1080 -f your-worker.workers.dev:443 -t your-token
```

### 方式三：使用 cargo run

```bash
cargo run --release -- -l 127.0.0.1:1080 -f your-worker.workers.dev:443 -t your-token
```

## 测试连接

### 1. 测试 SOCKS5

```bash
# 使用 curl 测试
curl --socks5 127.0.0.1:1080 https://www.google.com

# 或使用 wget
wget -e use_proxy=yes -e socks_proxy=127.0.0.1:1080 https://www.google.com
```

### 2. 配置浏览器

#### Chrome/Edge
1. 设置 → 系统 → 打开您计算机的代理设置
2. 手动代理设置
3. SOCKS 代理：`127.0.0.1:1080`
4. SOCKS 版本：SOCKS5

#### Firefox
1. 设置 → 网络设置 → 手动代理配置
2. SOCKS 主机：`127.0.0.1`
3. 端口：`1080`
4. SOCKS v5

## 常见用法示例

### 启用 ECH + 指纹随机化（推荐）

```bash
ech-client-rs \
  -l 127.0.0.1:1080 \
  -f worker.workers.dev:443 \
  -t your-token \
  --ech-domain cloudflare-ech.com \
  --dns-server dns.alidns.com/dns-query \
  --randomize-fingerprint true
```

### 禁用 ECH（Fallback 模式）

```bash
ech-client-rs \
  -l 127.0.0.1:1080 \
  -f worker.workers.dev:443 \
  -t your-token \
  --fallback
```

### 指定服务器 IP（绕过 DNS）

```bash
ech-client-rs \
  -l 127.0.0.1:1080 \
  -f worker.workers.dev:443 \
  --server-ip 104.21.12.34 \
  -t your-token
```

### 更换 DoH 服务器

```bash
# 使用 Cloudflare
ech-client-rs ... --dns-server 1.1.1.1/dns-query

# 使用 Google
ech-client-rs ... --dns-server dns.google/dns-query

# 使用阿里 DNS
ech-client-rs ... --dns-server dns.alidns.com/dns-query
```

## 环境变量

可以通过环境变量设置日志级别：

```bash
# Windows
set RUST_LOG=debug
ech-client-rs.exe ...

# Linux/macOS
RUST_LOG=debug ./ech-client-rs ...
```

日志级别：
- `error` - 仅错误
- `warn` - 警告和错误
- `info` - 信息、警告和错误（默认）
- `debug` - 调试信息
- `trace` - 所有详细信息

## 性能调优

### 增加并发连接（未来版本）

```bash
ech-client-rs -l 127.0.0.1:1080 -f worker.dev:443 -t token -n 4
```

### 编译优化

```bash
# 最小化二进制文件
cargo build --release
strip target/release/ech-client-rs  # Linux/macOS

# UPX 压缩（可选）
upx --best target/release/ech-client-rs
```

## 故障排除

### 问题：编译失败

```bash
# 清理并重新编译
cargo clean
cargo build --release
```

### 问题：连接失败

1. 检查服务器地址和端口
2. 检查令牌是否正确
3. 尝试禁用 ECH：添加 `--fallback` 参数
4. 检查防火墙设置

### 问题：ECH 配置获取失败

1. 测试 DoH 服务器可达性：
   ```bash
   curl https://dns.alidns.com/dns-query
   ```

2. 更换 DNS 服务器：
   ```bash
   --dns-server 1.1.1.1/dns-query
   ```

3. 检查网络连接

### 问题：TLS 握手失败

1. 检查系统时间是否正确
2. 更新根证书（Windows）：
   ```bash
   certutil -generateSSTFromWU roots.sst
   ```

## 下一步

- 阅读 [README.md](README.md) 了解完整功能
- 查看 [CHANGELOG.md](CHANGELOG.md) 了解版本历史
- 参考 Go 版本代码了解高级功能

## 获取帮助

```bash
# 查看所有参数
ech-client-rs --help

# 查看版本
ech-client-rs --version
```
