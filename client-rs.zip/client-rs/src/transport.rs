use anyhow::{Context, Result, anyhow};
use rustls::ClientConfig;
use rustls::client::{EchConfig, EchMode};
use rustls::crypto::aws_lc_rs;
use rustls::crypto::aws_lc_rs::hpke::ALL_SUPPORTED_SUITES;
use rustls::pki_types::ServerName;
use std::sync::Arc;
use tokio::net::TcpStream;
use tokio_tungstenite::tungstenite::protocol::Message;
use tracing::{info, debug, warn};

use crate::ech::EchManager;

/// 传输层实现
#[derive(Clone)]
pub struct Transport {
    server_addr: String,
    server_ip: Option<String>,
    token: String,
    ech_manager: Option<Arc<EchManager>>,
    randomize_fingerprint: bool,
}

impl Transport {
    pub async fn dial_with_retry(&self, max_retries: u32) -> Result<TunnelConnection> {
        let mut retries = 0;
        let mut backoff = 1;

        loop {
            match self.dial().await {
                Ok(conn) => {
                    if retries > 0 {
                        info!("重连成功（尝试 {} 次）", retries + 1);
                    }
                    return Ok(conn);
                }
                Err(e) => {
                    retries += 1;
                    if retries >= max_retries {
                        return Err(anyhow!("达到最大重试次数 {}: {}", max_retries, e));
                    }
                    
                    warn!("连接失败，{}秒后重试 ({}/{}): {}", backoff, retries, max_retries, e);
                    tokio::time::sleep(tokio::time::Duration::from_secs(backoff)).await;
                    backoff = (backoff * 2).min(30);
                }
            }
        }
    }

    pub fn new(
        server_addr: String,
        server_ip: Option<String>,
        token: String,
        ech_manager: Option<Arc<EchManager>>,
        randomize_fingerprint: bool,
    ) -> Self {
        Self {
            server_addr,
            server_ip,
            token,
            ech_manager,
            randomize_fingerprint,
        }
    }

    /// 建立 WebSocket 连接
    pub async fn dial(&self) -> Result<TunnelConnection> {
        let (host, port, path) = parse_server_addr(&self.server_addr)?;
        
        let ws_url = format!("wss://{}:{}{}", host, port, path);
        debug!("连接到: {}", ws_url);

        // 构建 TLS 配置
        let tls_config = self.build_tls_config(&host).await?;
        let connector = tokio_rustls::TlsConnector::from(Arc::new(tls_config));

        // 连接 TCP
        let tcp_addr = if let Some(ref ip) = self.server_ip {
            format!("{}:{}", ip, port)
        } else {
            format!("{}:{}", host, port)
        };

        debug!("TCP 连接到: {}", tcp_addr);
        let tcp_stream = TcpStream::connect(&tcp_addr)
            .await
            .context("TCP 连接失败")?;

        // TLS 握手
        let server_name = ServerName::try_from(host.to_string())
            .map_err(|_| anyhow!("无效的服务器名称"))?;

        debug!("开始 TLS 握手...");
        let tls_stream = connector
            .connect(server_name.to_owned(), tcp_stream)
            .await
            .context("TLS 握手失败")?;

        info!("TLS 连接建立成功");

        // 升级到 WebSocket
        debug!("升级到 WebSocket...");
        
        // 使用 tokio-tungstenite 直接连接
        let (ws_stream, _) = tokio_tungstenite::client_async(
            &ws_url,
            tls_stream,
        )
        .await
        .context("WebSocket 升级失败")?;

        info!("WebSocket 连接建立成功");

        Ok(TunnelConnection {
            ws_stream,
        })
    }

    /// 构建 TLS 配置（带 ECH 和指纹随机化）
    async fn build_tls_config(&self, server_name: &str) -> Result<ClientConfig> {
        // 加载系统根证书
        let mut root_store = rustls::RootCertStore::empty();
        
        // 使用 webpki-roots
        root_store.extend(
            webpki_roots::TLS_SERVER_ROOTS
                .iter()
                .cloned()
        );

        // 根据是否有 ECH 配置，选择不同的构建方式
        let mut config = if let Some(ref ech_manager) = self.ech_manager {
            // 获取 ECH 配置
            let ech_config_list = ech_manager.config();
            
            // 创建 EchConfig
            match EchConfig::new(ech_config_list, ALL_SUPPORTED_SUITES) {
                Ok(ech_config) => {
                    info!("✅ ECH 配置已加载");
                    
                    // 使用 TLS 1.3 专用 provider 并启用 ECH
                    ClientConfig::builder(aws_lc_rs::DEFAULT_TLS13_PROVIDER.into())
                        .with_ech(EchMode::Enable(ech_config))
                        .with_root_certificates(root_store)
                        .with_no_client_auth()
                        .context("构建带 ECH 的 TLS 配置失败")?
                }
                Err(e) => {
                    warn!("ECH 配置解析失败: {:?}，回退到普通 TLS", e);
                    ClientConfig::builder()
                        .with_root_certificates(root_store)
                        .with_no_client_auth()
                        .context("构建 TLS 配置失败")?
                }
            }
        } else {
            // 没有 ECH，使用普通 TLS 配置
            ClientConfig::builder()
                .with_root_certificates(root_store)
                .with_no_client_auth()
                .context("构建 TLS 配置失败")?
        };

        // 启用指纹随机化
        if self.randomize_fingerprint {
            config.randomize_fingerprint = true;
            info!("✅ TLS 指纹随机化已启用");
        }

        Ok(config)
    }
}

/// 隧道连接
pub struct TunnelConnection {
    ws_stream: WebSocketStream<tokio_rustls::client::TlsStream<TcpStream>>,
}

/// 支持自动重连的隧道连接
pub struct ReconnectableTunnelConnection {
    transport: Arc<Transport>,
    target: String,
    connection: Option<TunnelConnection>,
    max_retries: u32,
}

impl TunnelConnection {
    /// 发送 CONNECT 请求
    pub async fn connect(&mut self, target: &str, initial_data: &[u8]) -> Result<()> {
        let connect_msg = if initial_data.is_empty() {
            format!("CONNECT:{}|", target)
        } else {
            format!("CONNECT:{}|{}", target, String::from_utf8_lossy(initial_data))
        };

        debug!("发送 CONNECT: {}", target);
        
        self.ws_stream
            .send(Message::Text(connect_msg))
            .await
            .context("发送 CONNECT 失败")?;

        // 等待响应
        let msg = self.ws_stream
            .next()
            .await
            .ok_or_else(|| anyhow!("连接关闭"))??;

        match msg {
            Message::Text(text) => {
                if text == "CONNECTED" {
                    debug!("CONNECT 成功");
                    Ok(())
                } else if text.starts_with("ERROR:") {
                    Err(anyhow!("服务器错误: {}", text))
                } else {
                    Err(anyhow!("未预期的响应: {}", text))
                }
            }
            _ => Err(anyhow!("未预期的消息类型")),
        }
    }

    /// 读取数据
    pub async fn read(&mut self) -> Result<Vec<u8>> {
        use futures::StreamExt;
        
        let msg = self.ws_stream
            .next()
            .await
            .ok_or_else(|| anyhow!("连接关闭"))??;

        match msg {
            Message::Binary(data) => Ok(data),
            Message::Text(text) if text == "CLOSE" => {
                Err(anyhow!("服务器关闭连接"))
            }
            _ => Err(anyhow!("未预期的消息类型")),
        }
    }

    /// 写入数据
    pub async fn write(&mut self, data: &[u8]) -> Result<()> {
        self.ws_stream
            .send(Message::Binary(data.to_vec()))
            .await
            .context("发送数据失败")
    }

    /// 关闭连接
    pub async fn close(mut self) -> Result<()> {
        let _ = self.ws_stream.send(Message::Text("CLOSE".to_string())).await;
        let _ = self.ws_stream.close(None).await;
        Ok(())
    }
}

impl ReconnectableTunnelConnection {
    pub fn new(transport: Arc<Transport>, target: String, max_retries: u32) -> Self {
        Self {
            transport,
            target,
            connection: None,
            max_retries,
        }
    }

    async fn ensure_connected(&mut self) -> Result<()> {
        if self.connection.is_some() {
            return Ok(());
        }

        info!("建立新连接");
        let conn = self.transport.dial_with_retry(self.max_retries).await?;
        self.connection = Some(conn);
        Ok(())
    }

    pub async fn read(&mut self) -> Result<Vec<u8>> {
        self.ensure_connected().await?;

        match self.connection.as_mut().unwrap().read().await {
            Ok(data) => Ok(data),
            Err(e) => {
                warn!("读取失败，标记连接为断开: {}", e);
                self.connection = None;
                Err(e)
            }
        }
    }

    pub async fn write(&mut self, data: &[u8]) -> Result<()> {
        self.ensure_connected().await?;

        match self.connection.as_mut().unwrap().write(data).await {
            Ok(()) => Ok(()),
            Err(e) => {
                warn!("写入失败，标记连接为断开: {}", e);
                self.connection = None;
                Err(e)
            }
        }
    }

    pub async fn close(mut self) -> Result<()> {
        if let Some(conn) = self.connection.take() {
            conn.close().await?;
        }
        Ok(())
    }
}

/// 解析服务器地址
fn parse_server_addr(addr: &str) -> Result<(String, String, String)> {
    let (addr_part, path) = if let Some(idx) = addr.find('/') {
        (&addr[..idx], &addr[idx..])
    } else {
        (addr, "/")
    };

    let parts: Vec<&str> = addr_part.split(':').collect();
    
    if parts.len() != 2 {
        return Err(anyhow!("无效的服务器地址格式: {}", addr));
    }

    Ok((parts[0].to_string(), parts[1].to_string(), path.to_string()))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_parse_server_addr() {
        let (host, port, path) = parse_server_addr("example.com:443/ws").unwrap();
        assert_eq!(host, "example.com");
        assert_eq!(port, "443");
        assert_eq!(path, "/ws");

        let (host, port, path) = parse_server_addr("example.com:443").unwrap();
        assert_eq!(host, "example.com");
        assert_eq!(port, "443");
        assert_eq!(path, "/");
    }
}
