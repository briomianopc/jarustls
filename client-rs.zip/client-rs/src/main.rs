use anyhow::{Context, Result};
use clap::Parser;
use std::sync::Arc;
use tracing::{info, warn, error};

mod config;
mod ech;
mod transport;
mod grpc_transport;
mod proxy;
mod tun;
mod connection_map;
mod pool;

use config::Args;
use ech::EchManager;
use transport::Transport;
use grpc_transport::GrpcTransport;
use proxy::ProxyServer;
use tun::TunMode;

#[tokio::main]
async fn main() -> Result<()> {
    // 初始化日志
    tracing_subscriber::fmt()
        .with_env_filter(tracing_subscriber::EnvFilter::from_default_env()
            .add_directive(tracing::Level::INFO.into()))
        .init();

    // 解析命令行参数
    let args = Args::parse();
    
    info!("========================================");
    info!("ECH Tunnel Client (Rust + Fingerprint Randomization)");
    info!("========================================");
    
    if args.tun {
        info!("运行模式: TUN（全局代理）");
        info!("TUN IP: {}", args.tun_ip);
        info!("TUN 网关: {}", args.tun_gateway);
    } else {
        info!("监听地址: {}", args.listen);
    }
    
    info!("服务端: {}", args.server);
    info!("传输模式: {}", args.mode);
    info!("指纹随机化: {}", if args.randomize_fingerprint { "启用" } else { "禁用" });
    
    // 初始化 ECH 管理器
    let ech_manager = if !args.fallback {
        info!("正在获取 ECH 配置...");
        match EchManager::new(&args.ech_domain, &args.dns_server).await {
            Ok(manager) => {
                info!("ECH 配置已加载，长度: {} 字节", manager.config_len());
                Some(Arc::new(manager))
            }
            Err(e) => {
                warn!("ECH 配置获取失败，将使用普通 TLS: {}", e);
                None
            }
        }
    } else {
        info!("Fallback 模式：使用普通 TLS（不使用 ECH）");
        None
    };

    // 根据传输模式选择
    match args.mode.as_str() {
        "grpc" => {
            info!("使用 gRPC 传输模式");
            
            if args.tun {
                // TUN 模式 + gRPC
                let grpc_transport = GrpcTransport::new(
                    args.server.clone(),
                    args.server_ip.clone(),
                    args.uuid.clone(),
                    ech_manager.clone(),
                    args.randomize_fingerprint,
                );

                // TODO: TUN 模式需要适配不同的传输层接口
                warn!("TUN 模式 + gRPC 待完善");
                
            } else {
                // 普通代理模式 + gRPC
                warn!("gRPC 代理模式待完善（需要实现 gRPC 版本的 ProxyServer）");
            }
        }
        "ws" | _ => {
            info!("使用 WebSocket 传输模式");
            
            // 初始化 WebSocket 传输层
            let transport = Transport::new(
                args.server.clone(),
                args.server_ip.clone(),
                args.token.clone(),
                ech_manager.clone(),
                args.randomize_fingerprint,
            );

            if args.tun {
                // TUN 模式
                #[cfg(windows)]
                {
                    info!("正在启动 TUN 模式...");
                    let mut tun_mode = TunMode::new(
                        args.tun_ip.clone(),
                        args.tun_gateway.clone(),
                        args.tun_mask.clone(),
                        args.tun_dns.clone(),
                        Arc::new(transport),
                    );

                    tun_mode.start().await?;
                }
                
                #[cfg(not(windows))]
                {
                    error!("TUN 模式仅在 Windows 平台支持");
                    return Err(anyhow::anyhow!("TUN 模式仅在 Windows 平台支持"));
                }
            } else {
                // 普通代理模式
                info!("传输层初始化完成");
                info!("正在启动代理服务器...");
                
                let mut proxy_server = ProxyServer::new(
                    args.listen.clone(),
                    Arc::new(transport),
                );

                if args.num_conns > 1 {
                    info!("启用连接池（大小: {}）", args.num_conns);
                    proxy_server = proxy_server.with_pool(args.num_conns, 1);
                }

                proxy_server.run().await?;
            }
        }
    }

    Ok(())
}
