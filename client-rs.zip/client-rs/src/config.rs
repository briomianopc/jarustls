use clap::Parser;

#[derive(Parser, Debug, Clone)]
#[command(name = "ech-client-rs")]
#[command(about = "ECH Tunnel Client with Fingerprint Randomization", long_about = None)]
pub struct Args {
    /// 代理监听地址 (支持 SOCKS5 和 HTTP)
    #[arg(short = 'l', long, default_value = "127.0.0.1:30000")]
    pub listen: String,

    /// 服务端地址 (格式: x.x.workers.dev:443)
    #[arg(short = 'f', long)]
    pub server: String,

    /// 指定服务端 IP（绕过 DNS 解析）
    #[arg(long)]
    pub server_ip: Option<String>,

    /// 身份验证令牌
    #[arg(short = 't', long, default_value = "")]
    pub token: String,

    /// ECH 查询 DoH 服务器
    #[arg(long, default_value = "dns.alidns.com/dns-query")]
    pub dns_server: String,

    /// ECH 查询域名
    #[arg(long, default_value = "cloudflare-ech.com")]
    pub ech_domain: String,

    /// 禁用 ECH (普通 TLS 模式)
    #[arg(long)]
    pub fallback: bool,

    /// 传输协议模式: ws (WebSocket), grpc (gRPC)
    #[arg(long, default_value = "ws")]
    pub mode: String,

    /// UUID (用于 gRPC 鉴权)
    #[arg(long, default_value = "")]
    pub uuid: String,

    /// 启用 TLS 指纹随机化（推荐）
    #[arg(long, default_value = "true")]
    pub randomize_fingerprint: bool,

    /// 并发连接数
    #[arg(short = 'n', long, default_value = "1")]
    pub num_conns: usize,

    /// 启用 TUN 模式（全局代理，仅 Windows）
    #[arg(long)]
    pub tun: bool,

    /// TUN 设备 IP 地址
    #[arg(long, default_value = "10.0.85.2")]
    pub tun_ip: String,

    /// TUN 网关地址
    #[arg(long, default_value = "10.0.85.1")]
    pub tun_gateway: String,

    /// TUN 子网掩码
    #[arg(long, default_value = "255.255.255.0")]
    pub tun_mask: String,

    /// TUN DNS 服务器
    #[arg(long, default_value = "1.1.1.1")]
    pub tun_dns: String,
}
