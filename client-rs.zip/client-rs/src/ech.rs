use anyhow::{Context, Result, anyhow};
use base64::{Engine, engine::general_purpose::STANDARD as BASE64};
use reqwest;
use rustls::pki_types::EchConfigListBytes;
use tracing::{info, debug};

const TYPE_HTTPS: u16 = 65;

/// ECH 配置管理器
pub struct EchManager {
    config: Vec<u8>,
}

impl EchManager {
    /// 创建新的 ECH 管理器并获取配置
    pub async fn new(domain: &str, doh_server: &str) -> Result<Self> {
        let config = query_ech_config(domain, doh_server).await?;
        
        if config.is_empty() {
            return Err(anyhow!("ECH 配置为空"));
        }

        info!("ECH 配置获取成功，长度: {} 字节", config.len());
        
        Ok(Self { config })
    }

    /// 获取 ECH 配置（rustls 格式）
    pub fn config(&self) -> EchConfigListBytes<'static> {
        EchConfigListBytes::from(self.config.clone())
    }

    /// 获取配置长度
    pub fn config_len(&self) -> usize {
        self.config.len()
    }

    /// 刷新 ECH 配置
    pub async fn refresh(&mut self, domain: &str, doh_server: &str) -> Result<()> {
        info!("刷新 ECH 配置...");
        self.config = query_ech_config(domain, doh_server).await?;
        info!("ECH 配置刷新成功");
        Ok(())
    }
}

/// 通过 DoH 查询 ECH 配置
async fn query_ech_config(domain: &str, doh_server: &str) -> Result<Vec<u8>> {
    let doh_url = if !doh_server.starts_with("https://") && !doh_server.starts_with("http://") {
        format!("https://{}", doh_server)
    } else {
        doh_server.to_string()
    };

    debug!("查询 ECH 配置: {} via {}", domain, doh_url);

    // 构建 DNS 查询
    let dns_query = build_dns_query(domain, TYPE_HTTPS);
    let dns_base64 = BASE64.encode(&dns_query);

    // 发送 DoH 请求
    let url = format!("{}?dns={}", doh_url, dns_base64);
    
    let client = reqwest::Client::builder()
        .timeout(std::time::Duration::from_secs(10))
        .build()?;

    let response = client
        .get(&url)
        .header("Accept", "application/dns-message")
        .header("Content-Type", "application/dns-message")
        .send()
        .await
        .context("DoH 请求失败")?;

    if !response.status().is_success() {
        return Err(anyhow!("DoH 服务器返回错误: {}", response.status()));
    }

    let body = response.bytes().await?;

    // 解析 DNS 响应
    let ech_base64 = parse_dns_response(&body)?;
    
    if ech_base64.is_empty() {
        return Err(anyhow!("未找到 ECH 参数"));
    }

    // 解码 ECH 配置
    let ech_config = BASE64.decode(&ech_base64)
        .context("ECH 解码失败")?;

    Ok(ech_config)
}

/// 构建 DNS 查询包
fn build_dns_query(domain: &str, qtype: u16) -> Vec<u8> {
    let mut query = Vec::with_capacity(512);
    
    // DNS Header
    query.extend_from_slice(&[
        0x00, 0x01, // Transaction ID
        0x01, 0x00, // Flags (standard query)
        0x00, 0x01, // Questions: 1
        0x00, 0x00, // Answer RRs: 0
        0x00, 0x00, // Authority RRs: 0
        0x00, 0x00, // Additional RRs: 0
    ]);

    // Question section
    for label in domain.split('.') {
        query.push(label.len() as u8);
        query.extend_from_slice(label.as_bytes());
    }
    query.push(0x00); // End of domain name

    // Type and Class
    query.push((qtype >> 8) as u8);
    query.push((qtype & 0xFF) as u8);
    query.extend_from_slice(&[0x00, 0x01]); // Class: IN

    query
}

/// 解析 DNS 响应获取 ECH 配置
fn parse_dns_response(response: &[u8]) -> Result<String> {
    if response.len() < 12 {
        return Err(anyhow!("DNS 响应过短"));
    }

    let ancount = u16::from_be_bytes([response[6], response[7]]);
    
    if ancount == 0 {
        return Err(anyhow!("无应答记录"));
    }

    // Skip question section
    let mut offset = 12;
    while offset < response.len() && response[offset] != 0 {
        offset += response[offset] as usize + 1;
    }
    offset += 5; // Skip trailing null and QTYPE + QCLASS

    // Parse answer records
    for _ in 0..ancount {
        if offset >= response.len() {
            break;
        }

        // Skip name (compressed or full)
        if response[offset] & 0xC0 == 0xC0 {
            offset += 2;
        } else {
            while offset < response.len() && response[offset] != 0 {
                offset += response[offset] as usize + 1;
            }
            offset += 1;
        }

        if offset + 10 > response.len() {
            break;
        }

        let rr_type = u16::from_be_bytes([response[offset], response[offset + 1]]);
        offset += 8; // Skip TYPE, CLASS, TTL

        let data_len = u16::from_be_bytes([response[offset], response[offset + 1]]) as usize;
        offset += 2;

        if offset + data_len > response.len() {
            break;
        }

        let data = &response[offset..offset + data_len];
        offset += data_len;

        if rr_type == TYPE_HTTPS {
            if let Some(ech) = parse_https_record(data) {
                return Ok(ech);
            }
        }
    }

    Err(anyhow!("未找到 HTTPS 记录中的 ECH 参数"))
}

/// 解析 HTTPS 记录获取 ECH 参数
fn parse_https_record(data: &[u8]) -> Option<String> {
    if data.len() < 2 {
        return None;
    }

    let mut offset = 2; // Skip priority

    // Skip target name
    if offset < data.len() && data[offset] == 0 {
        offset += 1;
    } else {
        while offset < data.len() && data[offset] != 0 {
            offset += data[offset] as usize + 1;
        }
        offset += 1;
    }

    // Parse SvcParams
    while offset + 4 <= data.len() {
        let key = u16::from_be_bytes([data[offset], data[offset + 1]]);
        let length = u16::from_be_bytes([data[offset + 2], data[offset + 3]]) as usize;
        offset += 4;

        if offset + length > data.len() {
            break;
        }

        let value = &data[offset..offset + length];
        offset += length;

        // ECH key = 5
        if key == 5 {
            return Some(BASE64.encode(value));
        }
    }

    None
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_build_dns_query() {
        let query = build_dns_query("cloudflare-ech.com", TYPE_HTTPS);
        assert!(query.len() > 12);
        assert_eq!(&query[0..2], &[0x00, 0x01]); // Transaction ID
    }
}
