use anyhow::{Context, Result, anyhow};
use std::sync::Arc;
use tracing::{info, debug, warn, error};

#[cfg(windows)]
use wintun::Adapter;

use crate::transport::Transport;
use crate::connection_map::{ConnectionMap, ConnectionKey, TcpConnection, UdpConnection};

#[cfg(windows)]
pub struct TunMode {
    adapter: Option<Adapter>,
    tun_ip: String,
    tun_gateway: String,
    tun_mask: String,
    tun_dns: String,
    transport: Arc<Transport>,
    connection_map: ConnectionMap,
}

#[cfg(windows)]
impl TunMode {
    pub fn new(
        tun_ip: String,
        tun_gateway: String,
        tun_mask: String,
        tun_dns: String,
        transport: Arc<Transport>,
    ) -> Self {
        Self {
            adapter: None,
            tun_ip,
            tun_gateway,
            tun_mask,
            tun_dns,
            transport,
            connection_map: ConnectionMap::new(),
        }
    }

    /// 启动 TUN 模式
    pub async fn start(&mut self) -> Result<()> {
        info!("正在初始化 TUN 设备...");

        // 检查管理员权限
        if !is_elevated() {
            return Err(anyhow!("TUN 模式需要管理员权限"));
        }

        // 创建 Wintun 适配器
        let adapter = unsafe {
            wintun::load()?
                .create_adapter("ECH-TUN", "WireGuard", None)?
        };

        info!("TUN 适配器已创建");

        // 配置网络接口
        self.configure_interface(&adapter)?;

        // 配置路由
        self.configure_routing()?;

        self.adapter = Some(adapter);

        info!("TUN 模式已启动，IP: {}", self.tun_ip);

        // 启动数据包处理循环
        self.run_packet_loop().await?;

        Ok(())
    }

    /// 配置网络接口
    fn configure_interface(&self, adapter: &Adapter) -> Result<()> {
        use std::process::Command;

        let interface_name = "ECH-TUN";

        // 设置 IP 地址
        let output = Command::new("netsh")
            .args(&[
                "interface", "ip", "set", "address",
                &format!("name={}", interface_name),
                "source=static",
                &format!("addr={}", self.tun_ip),
                &format!("mask={}", self.tun_mask),
                &format!("gateway={}", self.tun_gateway),
            ])
            .output()
            .context("执行 netsh 失败")?;

        if !output.status.success() {
            let stderr = String::from_utf8_lossy(&output.stderr);
            return Err(anyhow!("配置网络接口失败: {}", stderr));
        }

        info!("接口配置: IP={}, Gateway={}, Mask={}", 
            self.tun_ip, self.tun_gateway, self.tun_mask);

        // 设置 DNS
        let output = Command::new("netsh")
            .args(&[
                "interface", "ip", "set", "dns",
                &format!("name={}", interface_name),
                "source=static",
                &format!("addr={}", self.tun_dns),
            ])
            .output()
            .context("设置 DNS 失败")?;

        if !output.status.success() {
            warn!("DNS 设置可能失败");
        }

        info!("DNS 设置: {}", self.tun_dns);

        Ok(())
    }

    /// 配置路由
    fn configure_routing(&self) -> Result<()> {
        use std::process::Command;

        // 添加默认路由
        let output = Command::new("route")
            .args(&[
                "add", "0.0.0.0", 
                "mask", "0.0.0.0", 
                &self.tun_gateway,
                "metric", "1",
            ])
            .output()
            .context("配置路由失败")?;

        if !output.status.success() {
            let stderr = String::from_utf8_lossy(&output.stderr);
            warn!("路由配置警告: {} (可能已存在)", stderr);
        }

        info!("路由表已配置（全局代理）");

        Ok(())
    }

    /// 运行数据包处理循环
    async fn run_packet_loop(&self) -> Result<()> {
        info!("TUN 数据包处理循环已启动");

        let adapter = self.adapter.as_ref().ok_or_else(|| anyhow!("适配器未初始化"))?;
        
        // 创建会话
        let session = unsafe {
            adapter.start_session(wintun::MAX_RING_CAPACITY)?
        };

        info!("Wintun 会话已启动");

        // 启动读取循环（从 TUN 设备读取并转发到网络）
        let transport = self.transport.clone();
        let conn_map = self.connection_map.clone();
        let session_reader = session.clone();
        tokio::spawn(async move {
            Self::tun_read_loop(session_reader, transport, conn_map).await;
        });

        // 启动写入循环（从网络接收并写入 TUN 设备）
        let session_writer = session.clone();
        tokio::spawn(async move {
            Self::tun_write_loop(session_writer).await;
        });

        info!("TUN 读写循环已启动");

        // 保持运行
        tokio::signal::ctrl_c().await?;

        Ok(())
    }

    /// TUN 读取循环：从 TUN 设备读取数据包
    async fn tun_read_loop(session: wintun::Session, transport: Arc<crate::transport::Transport>, conn_map: ConnectionMap) {
        let mut packet_buf = vec![0u8; 1500];

        loop {
            match session.receive_blocking() {
                Ok(packet) => {
                    let n = packet.bytes().len().min(packet_buf.len());
                    packet_buf[..n].copy_from_slice(&packet.bytes()[..n]);

                    // 解析 IP 数据包
                    if let Err(e) = Self::handle_ip_packet(&packet_buf[..n], &transport, &conn_map).await {
                        debug!("处理数据包失败: {}", e);
                    }
                }
                Err(e) => {
                    error!("读取 TUN 数据包失败: {}", e);
                    tokio::time::sleep(tokio::time::Duration::from_millis(100)).await;
                }
            }
        }
    }

    /// TUN 写入循环：写入数据包到 TUN 设备
    async fn tun_write_loop(session: wintun::Session) {
        // TODO: 实现从隧道接收的数据写回 TUN
        // 这需要维护连接状态映射
        warn!("TUN 写入循环待实现");
        
        loop {
            tokio::time::sleep(tokio::time::Duration::from_secs(1)).await;
        }
    }

    /// 处理 IP 数据包
    async fn handle_ip_packet(data: &[u8], transport: &Arc<crate::transport::Transport>, conn_map: &ConnectionMap) -> Result<()> {
        if data.len() < 20 {
            return Err(anyhow!("数据包过短"));
        }

        let version = data[0] >> 4;
        if version != 4 {
            return Err(anyhow!("仅支持 IPv4"));
        }

        let ihl = (data[0] & 0x0F) as usize * 4;
        let protocol = data[9];
        let src_ip = format!("{}.{}.{}.{}", data[12], data[13], data[14], data[15]);
        let dst_ip = format!("{}.{}.{}.{}", data[16], data[17], data[18], data[19]);

        match protocol {
            6 => {
                if data.len() < ihl + 4 {
                    return Err(anyhow!("TCP 数据包过短"));
                }
                
                let src_port = u16::from_be_bytes([data[ihl], data[ihl + 1]]);
                let dst_port = u16::from_be_bytes([data[ihl + 2], data[ihl + 3]]);
                
                Self::handle_tcp_packet(
                    src_ip, src_port, dst_ip, dst_port,
                    &data[ihl..], transport, conn_map
                ).await?;
            }
            17 => {
                if data.len() < ihl + 8 {
                    return Err(anyhow!("UDP 数据包过短"));
                }
                
                let src_port = u16::from_be_bytes([data[ihl], data[ihl + 1]]);
                let dst_port = u16::from_be_bytes([data[ihl + 2], data[ihl + 3]]);
                
                Self::handle_udp_packet(
                    src_ip, src_port, dst_ip, dst_port,
                    &data[ihl..], transport, conn_map
                ).await?;
            }
            _ => {
                debug!("不支持的协议: {}", protocol);
            }
        }

        Ok(())
    }

    /// 处理 TCP 数据包
    async fn handle_tcp_packet(
        src_ip: String, src_port: u16,
        dst_ip: String, dst_port: u16,
        tcp_data: &[u8],
        transport: &Arc<Transport>,
        conn_map: &ConnectionMap,
    ) -> Result<()> {
        let conn_key = ConnectionKey::new_tcp(
            src_ip.clone(), src_port,
            dst_ip.clone(), dst_port
        );

        if let Some(tx) = conn_map.get_tcp(&conn_key).await {
            if tcp_data.len() > 20 {
                let data_offset = ((tcp_data[12] >> 4) * 4) as usize;
                if tcp_data.len() > data_offset {
                    let payload = &tcp_data[data_offset..];
                    if !payload.is_empty() {
                        let _ = tx.send(payload.to_vec());
                    }
                }
            }
        } else {
            let flags = tcp_data[13];
            let syn = (flags & 0x02) != 0;
            
            if syn {
                debug!("新 TCP 连接: {}:{} -> {}:{}", src_ip, src_port, dst_ip, dst_port);
                
                let target = format!("{}:{}", dst_ip, dst_port);
                match transport.dial().await {
                    Ok(mut tunnel_conn) => {
                        if let Err(e) = tunnel_conn.connect(&target, &[]).await {
                            warn!("TCP CONNECT 失败: {}", e);
                            return Ok(());
                        }
                        let (tunnel_tx, mut tunnel_rx) = tokio::sync::mpsc::unbounded_channel();
                        let (tun_tx, mut tun_rx) = tokio::sync::mpsc::unbounded_channel();
                        
                        let tcp_conn = TcpConnection {
                            tunnel_tx: tunnel_tx.clone(),
                            tun_tx: tun_tx.clone(),
                        };
                        
                        conn_map.insert_tcp(conn_key.clone(), tcp_conn).await;
                        
                        let conn_map_clone = conn_map.clone();
                        let key_clone = conn_key.clone();
                        tokio::spawn(async move {
                            while let Some(data) = tunnel_rx.recv().await {
                                if let Err(e) = tunnel_conn.write(&data).await {
                                    error!("写入隧道失败: {}", e);
                                    break;
                                }
                            }
                            conn_map_clone.remove_tcp(&key_clone).await;
                        });
                        
                        let conn_map_clone = conn_map.clone();
                        let key_clone = conn_key.clone();
                        tokio::spawn(async move {
                            loop {
                                match tunnel_conn.read().await {
                                    Ok(data) => {
                                        if let Err(e) = tun_tx.send(data) {
                                            error!("发送到 TUN 失败: {}", e);
                                            break;
                                        }
                                    }
                                    Err(e) => {
                                        debug!("隧道读取结束: {}", e);
                                        break;
                                    }
                                }
                            }
                            conn_map_clone.remove_tcp(&key_clone).await;
                        });
                        
                        info!("TCP 隧道已建立: {}:{} -> {}:{}", src_ip, src_port, dst_ip, dst_port);
                    }
                    Err(e) => {
                        warn!("建立隧道连接失败: {}", e);
                    }
                }
            }
        }

        Ok(())
    }

    /// 处理 UDP 数据包
    async fn handle_udp_packet(
        src_ip: String, src_port: u16,
        dst_ip: String, dst_port: u16,
        udp_data: &[u8],
        transport: &Arc<Transport>,
        conn_map: &ConnectionMap,
    ) -> Result<()> {
        if udp_data.len() < 8 {
            return Err(anyhow!("UDP 数据包过短"));
        }

        let payload = &udp_data[8..];
        if payload.is_empty() {
            return Ok(());
        }

        let conn_key = ConnectionKey::new_udp(
            src_ip.clone(), src_port,
            dst_ip.clone(), dst_port
        );

        if let Some(tx) = conn_map.get_udp(&conn_key).await {
            let _ = tx.send(payload.to_vec());
        } else {
            debug!("新 UDP 连接: {}:{} -> {}:{}", src_ip, src_port, dst_ip, dst_port);
            
            let target = format!("{}:{}", dst_ip, dst_port);
            match transport.dial().await {
                Ok(mut tunnel_conn) => {
                    if let Err(e) = tunnel_conn.connect(&target, &[]).await {
                        warn!("UDP CONNECT 失败: {}", e);
                        return Ok(());
                    }
                    let (tunnel_tx, mut tunnel_rx) = tokio::sync::mpsc::unbounded_channel();
                    
                    let udp_conn = UdpConnection {
                        tunnel_tx: tunnel_tx.clone(),
                    };
                    
                    conn_map.insert_udp(conn_key.clone(), udp_conn).await;
                    
                    let _ = tunnel_tx.send(payload.to_vec());
                    
                    let conn_map_clone = conn_map.clone();
                    let key_clone = conn_key.clone();
                    tokio::spawn(async move {
                        while let Some(data) = tunnel_rx.recv().await {
                            if let Err(e) = tunnel_conn.write(&data).await {
                                error!("UDP 写入隧道失败: {}", e);
                                break;
                            }
                        }
                        conn_map_clone.remove_udp(&key_clone).await;
                    });
                    
                    let conn_map_clone = conn_map.clone();
                    let key_clone = conn_key.clone();
                    tokio::spawn(async move {
                        loop {
                            match tunnel_conn.read().await {
                                Ok(_data) => {
                                    debug!("收到 UDP 响应数据");
                                }
                                Err(e) => {
                                    debug!("UDP 隧道读取结束: {}", e);
                                    break;
                                }
                            }
                        }
                        conn_map_clone.remove_udp(&key_clone).await;
                    });
                    
                    info!("UDP 隧道已建立: {}:{} -> {}:{}", src_ip, src_port, dst_ip, dst_port);
                }
                Err(e) => {
                    warn!("建立 UDP 隧道连接失败: {}", e);
                }
            }
        }

        Ok(())
    }

    /// 清理资源
    pub fn cleanup(&mut self) {
        use std::process::Command;

        info!("正在清理 TUN 资源...");

        // 删除路由
        let _ = Command::new("route")
            .args(&["delete", "0.0.0.0", "mask", "0.0.0.0", &self.tun_gateway])
            .output();

        // 适配器会自动 drop
        self.adapter = None;

        info!("TUN 资源清理完成");
    }
}

#[cfg(windows)]
impl Drop for TunMode {
    fn drop(&mut self) {
        self.cleanup();
    }
}

#[cfg(windows)]
fn is_elevated() -> bool {
    use std::mem;
    use std::ptr;
    use winapi::um::handleapi::CloseHandle;
    use winapi::um::processthreadsapi::{GetCurrentProcess, OpenProcessToken};
    use winapi::um::securitybaseapi::GetTokenInformation;
    use winapi::um::winnt::{TokenElevation, TOKEN_ELEVATION, TOKEN_QUERY};

    unsafe {
        let mut token = ptr::null_mut();
        if OpenProcessToken(GetCurrentProcess(), TOKEN_QUERY, &mut token) == 0 {
            return false;
        }

        let mut elevation = TOKEN_ELEVATION { TokenIsElevated: 0 };
        let mut size = 0;

        let result = GetTokenInformation(
            token,
            TokenElevation,
            &mut elevation as *mut _ as *mut _,
            mem::size_of::<TOKEN_ELEVATION>() as u32,
            &mut size,
        );

        CloseHandle(token);

        result != 0 && elevation.TokenIsElevated != 0
    }
}

#[cfg(not(windows))]
pub struct TunMode;

#[cfg(not(windows))]
impl TunMode {
    pub fn new(
        _tun_ip: String,
        _tun_gateway: String,
        _tun_mask: String,
        _tun_dns: String,
        _transport: Arc<crate::transport::Transport>,
    ) -> Self {
        Self
    }

    pub async fn start(&mut self) -> Result<()> {
        Err(anyhow!("TUN 模式仅在 Windows 平台支持"))
    }

    pub fn cleanup(&mut self) {}
}
