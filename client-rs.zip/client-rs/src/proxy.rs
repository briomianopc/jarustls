use anyhow::{Context, Result, anyhow};
use std::sync::Arc;
use tokio::io::{AsyncReadExt, AsyncWriteExt};
use tokio::net::{TcpListener, TcpStream};
use tracing::{info, debug, error};

use crate::transport::Transport;
use crate::pool::ConnectionPool;

/// 代理服务器
pub struct ProxyServer {
    listen_addr: String,
    transport: Arc<Transport>,
    pool: Option<Arc<ConnectionPool>>,
    use_pool: bool,
}

impl ProxyServer {
    pub fn new(listen_addr: String, transport: Arc<Transport>) -> Self {
        Self {
            listen_addr,
            transport,
            pool: None,
            use_pool: false,
        }
    }

    pub fn with_pool(mut self, max_size: usize, min_idle: usize) -> Self {
        let pool = ConnectionPool::new(self.transport.clone(), max_size, min_idle);
        self.pool = Some(Arc::new(pool));
        self.use_pool = true;
        self
    }

    /// 运行代理服务器
    pub async fn run(&self) -> Result<()> {
        let listener = TcpListener::bind(&self.listen_addr)
            .await
            .context(format!("无法绑定到 {}", self.listen_addr))?;

        info!("✅ 代理服务器启动成功");
        info!("📡 监听地址: {}", self.listen_addr);
        info!("🔒 支持协议: SOCKS5, HTTP CONNECT");
        
        if self.use_pool {
            info!("🏊 连接池: 已启用");
            if let Some(ref pool) = self.pool {
                info!("   最大连接数: {}", pool.max_size);
                info!("   最小空闲: {}", pool.min_idle);
            }
        } else {
            info!("🏊 连接池: 未启用");
        }
        info!("");

        loop {
            match listener.accept().await {
                Ok((socket, addr)) => {
                    debug!("新连接来自: {}", addr);
                    let transport = Arc::clone(&self.transport);
                    let pool = self.pool.clone();
                    let use_pool = self.use_pool;
                    
                    tokio::spawn(async move {
                        if let Err(e) = handle_client(socket, transport, pool, use_pool).await {
                            if !is_normal_error(&e) {
                                error!("处理客户端连接失败: {}", e);
                            }
                        }
                    });
                }
                Err(e) => {
                    error!("接受连接失败: {}", e);
                }
            }
        }
    }
}

/// 处理客户端连接
async fn handle_client(
    mut socket: TcpStream, 
    transport: Arc<Transport>,
    pool: Option<Arc<ConnectionPool>>,
    use_pool: bool,
) -> Result<()> {
    let mut buf = [0u8; 2];
    socket.read_exact(&mut buf).await?;

    match buf[0] {
        // SOCKS5
        0x05 => {
            debug!("检测到 SOCKS5 协议");
            handle_socks5(socket, transport, pool, use_pool).await
        }
        // HTTP CONNECT (probably)
        _ => {
            debug!("尝试 HTTP CONNECT 协议");
            // 将已读取的字节放回
            let mut full_buf = Vec::new();
            full_buf.extend_from_slice(&buf);
            
            let mut rest = Vec::new();
            socket.read_to_end(&mut rest).await?;
            full_buf.extend_from_slice(&rest);
            
            handle_http_connect(socket, transport, pool, use_pool, &full_buf).await
        }
    }
}

/// 处理 SOCKS5 连接
async fn handle_socks5(
    mut socket: TcpStream, 
    transport: Arc<Transport>,
    pool: Option<Arc<ConnectionPool>>,
    use_pool: bool,
) -> Result<()> {
    // 读取方法数量
    let mut buf = [0u8; 1];
    socket.read_exact(&mut buf).await?;
    let nmethods = buf[0] as usize;

    // 读取方法列表
    let mut methods = vec![0u8; nmethods];
    socket.read_exact(&mut methods).await?;

    // 响应：无需认证
    socket.write_all(&[0x05, 0x00]).await?;

    // 读取请求
    let mut header = [0u8; 4];
    socket.read_exact(&mut header).await?;

    if header[0] != 0x05 {
        return Err(anyhow!("不支持的 SOCKS 版本"));
    }

    if header[1] != 0x01 {
        return Err(anyhow!("不支持的 SOCKS 命令"));
    }

    // 解析目标地址
    let target = match header[3] {
        // IPv4
        0x01 => {
            let mut addr = [0u8; 4];
            socket.read_exact(&mut addr).await?;
            let mut port = [0u8; 2];
            socket.read_exact(&mut port).await?;
            let port = u16::from_be_bytes(port);
            
            format!("{}.{}.{}.{}:{}", addr[0], addr[1], addr[2], addr[3], port)
        }
        // 域名
        0x03 => {
            let mut len = [0u8; 1];
            socket.read_exact(&mut len).await?;
            let mut domain = vec![0u8; len[0] as usize];
            socket.read_exact(&mut domain).await?;
            let mut port = [0u8; 2];
            socket.read_exact(&mut port).await?;
            let port = u16::from_be_bytes(port);
            
            format!("{}:{}", String::from_utf8_lossy(&domain), port)
        }
        // IPv6
        0x04 => {
            let mut addr = [0u8; 16];
            socket.read_exact(&mut addr).await?;
            let mut port = [0u8; 2];
            socket.read_exact(&mut port).await?;
            let port = u16::from_be_bytes(port);
            
            format!("[{:02x}{:02x}:{:02x}{:02x}:{:02x}{:02x}:{:02x}{:02x}:{:02x}{:02x}:{:02x}{:02x}:{:02x}{:02x}:{:02x}{:02x}]:{}",
                addr[0], addr[1], addr[2], addr[3], addr[4], addr[5], addr[6], addr[7],
                addr[8], addr[9], addr[10], addr[11], addr[12], addr[13], addr[14], addr[15],
                port)
        }
        _ => return Err(anyhow!("不支持的地址类型")),
    };

    debug!("SOCKS5 目标: {}", target);

    // 响应成功
    socket.write_all(&[0x05, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]).await?;

    // 建立隧道连接（使用连接池或直接连接）
    if use_pool && pool.is_some() {
        let pool = pool.unwrap();
        let mut tunnel = pool.acquire().await?;
        tunnel.connect(&target, &[]).await?;
        relay_data_pooled(socket, tunnel).await?;
    } else {
        let mut tunnel = transport.dial().await?;
        tunnel.connect(&target, &[]).await?;
        relay_data(socket, tunnel).await?;
    }

    Ok(())
}

/// 处理 HTTP CONNECT
async fn handle_http_connect(
    mut socket: TcpStream,
    transport: Arc<Transport>,
    pool: Option<Arc<ConnectionPool>>,
    use_pool: bool,
    initial_data: &[u8],
) -> Result<()> {
    // 解析 HTTP CONNECT 请求
    let request = String::from_utf8_lossy(initial_data);
    let lines: Vec<&str> = request.lines().collect();
    
    if lines.is_empty() {
        return Err(anyhow!("无效的 HTTP 请求"));
    }

    let parts: Vec<&str> = lines[0].split_whitespace().collect();
    if parts.len() < 2 {
        return Err(anyhow!("无效的 HTTP 请求行"));
    }

    let method = parts[0];
    let target = parts[1];

    if method != "CONNECT" {
        // 不是 CONNECT，可能是普通的 HTTP 请求
        // 这里简单返回错误，实际可以支持 HTTP 代理
        socket.write_all(b"HTTP/1.1 405 Method Not Allowed\r\n\r\n").await?;
        return Err(anyhow!("仅支持 CONNECT 方法"));
    }

    debug!("HTTP CONNECT 目标: {}", target);

    // 响应成功
    socket.write_all(b"HTTP/1.1 200 Connection Established\r\n\r\n").await?;

    // 建立隧道连接（使用连接池或直接连接）
    if use_pool && pool.is_some() {
        let pool = pool.unwrap();
        let mut tunnel = pool.acquire().await?;
        tunnel.connect(target, &[]).await?;
        relay_data_pooled(socket, tunnel).await?;
    } else {
        let mut tunnel = transport.dial().await?;
        tunnel.connect(target, &[]).await?;
        relay_data(socket, tunnel).await?;
    }

    Ok(())
}

/// 双向转发数据
async fn relay_data(
    mut local: TcpStream,
    mut remote: crate::transport::TunnelConnection,
) -> Result<()> {
    let (mut local_read, mut local_write) = local.split();
    
    // 本地 -> 远程
    let local_to_remote = async {
        let mut buf = [0u8; 8192];
        loop {
            match local_read.read(&mut buf).await {
                Ok(0) => break,
                Ok(n) => {
                    if let Err(e) = remote.write(&buf[..n]).await {
                        if !is_normal_error(&e) {
                            error!("写入远程失败: {}", e);
                        }
                        break;
                    }
                }
                Err(e) => {
                    if !is_normal_error(&e.into()) {
                        error!("读取本地失败: {}", e);
                    }
                    break;
                }
            }
        }
    };

    // 远程 -> 本地
    let remote_to_local = async {
        loop {
            match remote.read().await {
                Ok(data) => {
                    if let Err(e) = local_write.write_all(&data).await {
                        if !is_normal_error(&e.into()) {
                            error!("写入本地失败: {}", e);
                        }
                        break;
                    }
                }
                Err(e) => {
                    if !is_normal_error(&e) {
                        error!("读取远程失败: {}", e);
                    }
                    break;
                }
            }
        }
    };

    // 并发执行双向转发
    tokio::select! {
        _ = local_to_remote => {},
        _ = remote_to_local => {},
    }

    debug!("连接关闭");
    Ok(())
}

/// 双向转发数据（使用池化连接）
async fn relay_data_pooled(
    mut local: TcpStream,
    mut remote: crate::pool::PooledConnection,
) -> Result<()> {
    let (mut local_read, mut local_write) = local.split();
    
    // 本地 -> 远程
    let local_to_remote = async {
        let mut buf = [0u8; 8192];
        loop {
            match local_read.read(&mut buf).await {
                Ok(0) => break,
                Ok(n) => {
                    if let Err(e) = remote.write(&buf[..n]).await {
                        if !is_normal_error(&e) {
                            error!("写入远程失败: {}", e);
                        }
                        break;
                    }
                }
                Err(e) => {
                    if !is_normal_error(&e.into()) {
                        error!("读取本地失败: {}", e);
                    }
                    break;
                }
            }
        }
    };

    // 远程 -> 本地
    let remote_to_local = async {
        loop {
            match remote.read().await {
                Ok(data) => {
                    if let Err(e) = local_write.write_all(&data).await {
                        if !is_normal_error(&e.into()) {
                            error!("写入本地失败: {}", e);
                        }
                        break;
                    }
                }
                Err(e) => {
                    if !is_normal_error(&e) {
                        error!("读取远程失败: {}", e);
                    }
                    break;
                }
            }
        }
    };

    // 并发执行双向转发
    tokio::select! {
        _ = local_to_remote => {},
        _ = remote_to_local => {},
    }

    debug!("池化连接关闭");
    Ok(())
}

/// 判断是否是正常的错误（连接关闭等）
fn is_normal_error(err: &anyhow::Error) -> bool {
    let err_str = err.to_string().to_lowercase();
    err_str.contains("connection") && 
        (err_str.contains("reset") || 
         err_str.contains("closed") || 
         err_str.contains("broken pipe") ||
         err_str.contains("eof"))
}
