use anyhow::Result;
use std::collections::HashMap;
use std::sync::Arc;
use tokio::sync::Mutex;
use tracing::{debug, warn};

#[derive(Debug, Clone, Hash, Eq, PartialEq)]
pub struct ConnectionKey {
    pub protocol: u8,
    pub src_ip: String,
    pub src_port: u16,
    pub dst_ip: String,
    pub dst_port: u16,
}

impl ConnectionKey {
    pub fn new_tcp(src_ip: String, src_port: u16, dst_ip: String, dst_port: u16) -> Self {
        Self {
            protocol: 6,
            src_ip,
            src_port,
            dst_ip,
            dst_port,
        }
    }

    pub fn new_udp(src_ip: String, src_port: u16, dst_ip: String, dst_port: u16) -> Self {
        Self {
            protocol: 17,
            src_ip,
            src_port,
            dst_ip,
            dst_port,
        }
    }

    pub fn reverse(&self) -> Self {
        Self {
            protocol: self.protocol,
            src_ip: self.dst_ip.clone(),
            src_port: self.dst_port,
            dst_ip: self.src_ip.clone(),
            dst_port: self.src_port,
        }
    }
}

pub struct TcpConnection {
    pub tunnel_tx: tokio::sync::mpsc::UnboundedSender<Vec<u8>>,
    pub tun_tx: tokio::sync::mpsc::UnboundedSender<Vec<u8>>,
}

pub struct UdpConnection {
    pub tunnel_tx: tokio::sync::mpsc::UnboundedSender<Vec<u8>>,
}

pub struct ConnectionMap {
    tcp_connections: Arc<Mutex<HashMap<ConnectionKey, TcpConnection>>>,
    udp_connections: Arc<Mutex<HashMap<ConnectionKey, UdpConnection>>>,
}

impl ConnectionMap {
    pub fn new() -> Self {
        Self {
            tcp_connections: Arc::new(Mutex::new(HashMap::new())),
            udp_connections: Arc::new(Mutex::new(HashMap::new())),
        }
    }

    pub async fn insert_tcp(&self, key: ConnectionKey, conn: TcpConnection) {
        let mut map = self.tcp_connections.lock().await;
        debug!("插入 TCP 连接: {:?}", key);
        map.insert(key, conn);
    }

    pub async fn get_tcp(&self, key: &ConnectionKey) -> Option<tokio::sync::mpsc::UnboundedSender<Vec<u8>>> {
        let map = self.tcp_connections.lock().await;
        map.get(key).map(|conn| conn.tunnel_tx.clone())
    }

    pub async fn remove_tcp(&self, key: &ConnectionKey) {
        let mut map = self.tcp_connections.lock().await;
        if map.remove(key).is_some() {
            debug!("删除 TCP 连接: {:?}", key);
        }
    }

    pub async fn insert_udp(&self, key: ConnectionKey, conn: UdpConnection) {
        let mut map = self.udp_connections.lock().await;
        debug!("插入 UDP 连接: {:?}", key);
        map.insert(key, conn);
    }

    pub async fn get_udp(&self, key: &ConnectionKey) -> Option<tokio::sync::mpsc::UnboundedSender<Vec<u8>>> {
        let map = self.udp_connections.lock().await;
        map.get(key).map(|conn| conn.tunnel_tx.clone())
    }

    pub async fn remove_udp(&self, key: &ConnectionKey) {
        let mut map = self.udp_connections.lock().await;
        if map.remove(key).is_some() {
            debug!("删除 UDP 连接: {:?}", key);
        }
    }

    pub async fn tcp_count(&self) -> usize {
        self.tcp_connections.lock().await.len()
    }

    pub async fn udp_count(&self) -> usize {
        self.udp_connections.lock().await.len()
    }

    pub async fn cleanup_inactive(&self, timeout_secs: u64) {
        warn!("清理不活跃连接（超时: {}秒）待实现", timeout_secs);
    }
}

impl Clone for ConnectionMap {
    fn clone(&self) -> Self {
        Self {
            tcp_connections: self.tcp_connections.clone(),
            udp_connections: self.udp_connections.clone(),
        }
    }
}
