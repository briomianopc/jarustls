use anyhow::Result;
use std::sync::Arc;
use tokio::sync::Mutex;
use tracing::{info, debug, warn};

use crate::transport::{Transport, TunnelConnection};

pub struct ConnectionPool {
    transport: Arc<Transport>,
    pool: Arc<Mutex<Vec<TunnelConnection>>>,
    pub max_size: usize,
    pub min_idle: usize,
}

impl ConnectionPool {
    pub fn new(transport: Arc<Transport>, max_size: usize, min_idle: usize) -> Self {
        Self {
            transport,
            pool: Arc::new(Mutex::new(Vec::with_capacity(max_size))),
            max_size,
            min_idle,
        }
    }

    pub async fn acquire(&self) -> Result<PooledConnection> {
        let mut pool = self.pool.lock().await;
        
        if let Some(conn) = pool.pop() {
            debug!("从连接池获取连接（剩余: {}）", pool.len());
            drop(pool);
            return Ok(PooledConnection::new(conn, self.pool.clone()));
        }

        drop(pool);
        
        debug!("连接池为空，创建新连接");
        let conn = self.transport.dial().await?;
        Ok(PooledConnection::new(conn, self.pool.clone()))
    }

    pub async fn size(&self) -> usize {
        self.pool.lock().await.len()
    }

    pub async fn ensure_min_idle(&self) {
        let current_size = self.size().await;
        
        if current_size < self.min_idle {
            let needed = self.min_idle - current_size;
            info!("预热连接池：创建 {} 个空闲连接", needed);
            
            for _ in 0..needed {
                match self.transport.dial().await {
                    Ok(conn) => {
                        let mut pool = self.pool.lock().await;
                        if pool.len() < self.max_size {
                            pool.push(conn);
                        }
                    }
                    Err(e) => {
                        warn!("预热连接失败: {}", e);
                        break;
                    }
                }
            }
        }
    }

    pub async fn clear(&self) {
        let mut pool = self.pool.lock().await;
        let count = pool.len();
        pool.clear();
        info!("清空连接池（关闭 {} 个连接）", count);
    }
}

pub struct PooledConnection {
    connection: Option<TunnelConnection>,
    pool: Arc<Mutex<Vec<TunnelConnection>>>,
}

impl PooledConnection {
    fn new(connection: TunnelConnection, pool: Arc<Mutex<Vec<TunnelConnection>>>) -> Self {
        Self {
            connection: Some(connection),
            pool,
        }
    }

    pub async fn read(&mut self) -> Result<Vec<u8>> {
        self.connection.as_mut()
            .ok_or_else(|| anyhow::anyhow!("连接已关闭"))?
            .read()
            .await
    }

    pub async fn write(&mut self, data: &[u8]) -> Result<()> {
        self.connection.as_mut()
            .ok_or_else(|| anyhow::anyhow!("连接已关闭"))?
            .write(data)
            .await
    }

    pub async fn connect(&mut self, target: &str, initial_data: &[u8]) -> Result<()> {
        self.connection.as_mut()
            .ok_or_else(|| anyhow::anyhow!("连接已关闭"))?
            .connect(target, initial_data)
            .await
    }

    async fn return_to_pool(mut self) {
        if let Some(conn) = self.connection.take() {
            let mut pool = self.pool.lock().await;
            pool.push(conn);
            debug!("连接归还到池（当前: {}）", pool.len());
        }
    }
}

impl Drop for PooledConnection {
    fn drop(&mut self) {
        if let Some(conn) = self.connection.take() {
            let pool = self.pool.clone();
            tokio::spawn(async move {
                let mut pool = pool.lock().await;
                pool.push(conn);
            });
        }
    }
}
