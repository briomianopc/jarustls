use anyhow::{Context, Result, anyhow};
use rustls::ClientConfig;
use rustls::client::{EchConfig, EchMode};
use rustls::crypto::aws_lc_rs;
use rustls::crypto::aws_lc_rs::hpke::ALL_SUPPORTED_SUITES;
use std::sync::Arc;
use std::task::{Context as TaskContext, Poll};
use std::future::Future;
use std::pin::Pin;
use tokio::net::TcpStream;
use tokio_rustls::TlsConnector;
use tonic::transport::{Channel, Endpoint, Uri};
use tonic::metadata::MetadataValue;
use tokio::sync::Mutex;
use futures::{StreamExt, SinkExt, stream};
use tower::Service;
use hyper_util::rt::TokioIo;
use tracing::{info, debug, warn};

use crate::ech::EchManager;

pub mod tunnel {
    tonic::include_proto!("tunnel");
}

use tunnel::{proxy_service_client::ProxyServiceClient, SocketData};

/// gRPC 传输层实现
#[derive(Clone)]
pub struct GrpcTransport {
    server_addr: String,
    server_ip: Option<String>,
    uuid: String,
    ech_manager: Option<Arc<EchManager>>,
    randomize_fingerprint: bool,
}

impl GrpcTransport {
    pub async fn dial_with_retry(&self, max_retries: u32) -> Result<GrpcTunnelConnection> {
        let mut retries = 0;
        let mut backoff = 1;

        loop {
            match self.dial().await {
                Ok(conn) => {
                    if retries > 0 {
                        info!("gRPC 重连成功（尝试 {} 次）", retries + 1);
                    }
                    return Ok(conn);
                }
                Err(e) => {
                    retries += 1;
                    if retries >= max_retries {
                        return Err(anyhow!("gRPC 达到最大重试次数 {}: {}", max_retries, e));
                    }
                    
                    warn!("gRPC 连接失败，{}秒后重试 ({}/{}): {}", backoff, retries, max_retries, e);
                    tokio::time::sleep(tokio::time::Duration::from_secs(backoff)).await;
                    backoff = (backoff * 2).min(30);
                }
            }
        }
    }

    pub fn new(
        server_addr: String,
        server_ip: Option<String>,
        uuid: String,
        ech_manager: Option<Arc<EchManager>>,
        randomize_fingerprint: bool,
    ) -> Self {
        Self {
            server_addr,
            server_ip,
            uuid,
            ech_manager,
            randomize_fingerprint,
        }
    }

    /// 构建 TLS 配置
    async fn build_tls_config(&self, server_name: &str) -> Result<ClientConfig> {
        let mut root_store = rustls::RootCertStore::empty();
        root_store.extend(
            webpki_roots::TLS_SERVER_ROOTS
                .iter()
                .cloned()
        );

        let mut config = if let Some(ref ech_manager) = self.ech_manager {
            let ech_config_list = ech_manager.config();
            match EchConfig::new(ech_config_list, ALL_SUPPORTED_SUITES) {
                Ok(ech_config) => {
                    info!("✅ gRPC ECH 配置已加载");
                    ClientConfig::builder(aws_lc_rs::DEFAULT_TLS13_PROVIDER.into())
                        .with_ech(EchMode::Enable(ech_config))
                        .with_root_certificates(root_store)
                        .with_no_client_auth()
                        .context("构建带 ECH 的 TLS 配置失败")?
                }
                Err(e) => {
                    warn!("gRPC ECH 配置解析失败: {:?}，回退到普通 TLS", e);
                    ClientConfig::builder()
                        .with_root_certificates(root_store)
                        .with_no_client_auth()
                        .context("构建 TLS 配置失败")?
                }
            }
        } else {
            ClientConfig::builder()
                .with_root_certificates(root_store)
                .with_no_client_auth()
                .context("构建 TLS 配置失败")?
        };

        if self.randomize_fingerprint {
            config.randomize_fingerprint = true;
            info!("✅ gRPC TLS 指纹随机化已启用");
        }

        Ok(config)
    }

    /// 建立 gRPC 连接
    pub async fn dial(&self) -> Result<GrpcTunnelConnection> {
        let (host, port) = parse_server_addr(&self.server_addr)?;
        
        // 确定连接地址
        let addr = if let Some(ref ip) = self.server_ip {
            format!("https://{}:{}", ip, port)
        } else {
            format!("https://{}:{}", host, port)
        };

        debug!("gRPC 连接到: {}", addr);

        // 构建 TLS 配置
        let tls_config = self.build_tls_config(&host).await?;
        let connector = RustlsConnector {
            tls_config: Arc::new(tls_config),
            server_name: host.clone(),
        };

        // 创建 gRPC endpoint 并使用自定义 connector
        let endpoint = Endpoint::from_shared(addr)?
            .timeout(std::time::Duration::from_secs(10))
            .tcp_keepalive(Some(std::time::Duration::from_secs(30)));

        let channel = endpoint.connect_with_connector(connector).await?;

        info!("gRPC 连接建立成功（ECH + 指纹随机化）");

        // 创建客户端
        let mut client = ProxyServiceClient::new(channel);

        // 创建双向流，添加 metadata (uuid)
        let mut request = tonic::Request::new(stream::pending());
        request.metadata_mut().insert(
            "uuid",
            MetadataValue::try_from(&self.uuid)?,
        );

        let response = client.tunnel(request).await?;
        let stream = response.into_inner();

        // 分离发送和接收端
        let (tx, rx) = tokio::sync::mpsc::unbounded_channel();

        Ok(GrpcTunnelConnection {
            tx,
            rx: Arc::new(Mutex::new(stream)),
        })
    }
}

/// gRPC 隧道连接
pub struct GrpcTunnelConnection {
    tx: tokio::sync::mpsc::UnboundedSender<SocketData>,
    rx: Arc<Mutex<tonic::Streaming<SocketData>>>,
}

/// 支持自动重连的 gRPC 隧道连接
pub struct ReconnectableGrpcConnection {
    transport: Arc<GrpcTransport>,
    target: String,
    connection: Option<GrpcTunnelConnection>,
    max_retries: u32,
}

impl GrpcTunnelConnection {
    /// 发送 CONNECT 请求
    pub async fn connect(&mut self, target: &str, initial_data: &[u8]) -> Result<()> {
        let connect_msg = if initial_data.is_empty() {
            format!("CONNECT:{}|", target)
        } else {
            format!("CONNECT:{}|{}", target, String::from_utf8_lossy(initial_data))
        };

        debug!("发送 gRPC CONNECT: {}", target);
        
        self.tx.send(SocketData {
            content: connect_msg.into_bytes(),
        })?;

        // 等待响应
        let mut rx = self.rx.lock().await;
        if let Some(data) = rx.next().await {
            let socket_data = data.context("gRPC stream error")?;
            let response = String::from_utf8_lossy(&socket_data.content);
            
            if response.starts_with("ERROR:") {
                return Err(anyhow!("{}", response));
            }
            if response != "CONNECTED" {
                return Err(anyhow!("unexpected response: {}", response));
            }
            
            debug!("gRPC CONNECT 成功");
            Ok(())
        } else {
            Err(anyhow!("连接关闭"))
        }
    }

    /// 读取数据
    pub async fn read(&mut self) -> Result<Vec<u8>> {
        let mut rx = self.rx.lock().await;
        
        if let Some(data) = rx.next().await {
            let socket_data = data.context("gRPC stream error")?;
            
            let content = socket_data.content;
            if content == b"CLOSE" {
                return Err(anyhow!("服务器关闭连接"));
            }
            
            Ok(content)
        } else {
            Err(anyhow!("连接关闭"))
        }
    }

    /// 写入数据
    pub async fn write(&mut self, data: &[u8]) -> Result<()> {
        self.tx.send(SocketData {
            content: data.to_vec(),
        })?;
        
        Ok(())
    }

    /// 关闭连接
    pub async fn close(self) -> Result<()> {
        let _ = self.tx.send(SocketData {
            content: b"CLOSE".to_vec(),
        });
        
        Ok(())
    }
}

impl ReconnectableGrpcConnection {
    pub fn new(transport: Arc<GrpcTransport>, target: String, max_retries: u32) -> Self {
        Self {
            transport,
            target,
            connection: None,
            max_retries,
        }
    }

    async fn ensure_connected(&mut self) -> Result<()> {
        if self.connection.is_some() {
            return Ok(());
        }

        info!("建立新 gRPC 连接到 {}", self.target);
        let mut conn = self.transport.dial_with_retry(self.max_retries).await?;
        conn.connect(&self.target, &[]).await?;
        self.connection = Some(conn);
        Ok(())
    }

    pub async fn read(&mut self) -> Result<Vec<u8>> {
        self.ensure_connected().await?;

        match self.connection.as_mut().unwrap().read().await {
            Ok(data) => Ok(data),
            Err(e) => {
                warn!("gRPC 读取失败，标记连接为断开: {}", e);
                self.connection = None;
                Err(e)
            }
        }
    }

    pub async fn write(&mut self, data: &[u8]) -> Result<()> {
        self.ensure_connected().await?;

        match self.connection.as_mut().unwrap().write(data).await {
            Ok(()) => Ok(()),
            Err(e) => {
                warn!("gRPC 写入失败，标记连接为断开: {}", e);
                self.connection = None;
                Err(e)
            }
        }
    }

    pub async fn close(mut self) -> Result<()> {
        if let Some(conn) = self.connection.take() {
            conn.close().await?;
        }
        Ok(())
    }
}

/// 自定义 Rustls Connector（支持 ECH + 指纹随机化）
#[derive(Clone)]
struct RustlsConnector {
    tls_config: Arc<ClientConfig>,
    server_name: String,
}

impl Service<Uri> for RustlsConnector {
    type Response = TokioIo<tokio_rustls::client::TlsStream<TcpStream>>;
    type Error = Box<dyn std::error::Error + Send + Sync>;
    type Future = Pin<Box<dyn Future<Output = Result<Self::Response, Self::Error>> + Send>>;

    fn poll_ready(&mut self, _cx: &mut TaskContext<'_>) -> Poll<Result<(), Self::Error>> {
        Poll::Ready(Ok(()))
    }

    fn call(&mut self, uri: Uri) -> Self::Future {
        let tls_config = self.tls_config.clone();
        let server_name = self.server_name.clone();
        
        Box::pin(async move {
            let host = uri.host().ok_or("missing host")?;
            let port = uri.port_u16().unwrap_or(443);
            
            debug!("Connecting to {}:{}", host, port);
            
            // 建立 TCP 连接
            let tcp_stream = TcpStream::connect((host, port)).await?;
            
            // 建立 TLS 连接
            let connector = TlsConnector::from(tls_config);
            let domain = rustls::pki_types::ServerName::try_from(server_name.as_str())
                .map_err(|_| "invalid server name")?
                .to_owned();
            
            let tls_stream = connector.connect(domain, tcp_stream).await?;
            
            Ok(TokioIo::new(tls_stream))
        })
    }
}

/// 解析服务器地址
fn parse_server_addr(addr: &str) -> Result<(String, String)> {
    let (addr_part, _path) = if let Some(idx) = addr.find('/') {
        (&addr[..idx], &addr[idx..])
    } else {
        (addr, "")
    };

    let parts: Vec<&str> = addr_part.split(':').collect();
    
    if parts.len() != 2 {
        return Err(anyhow!("无效的服务器地址格式: {}", addr));
    }

    Ok((parts[0].to_string(), parts[1].to_string()))
}
