@echo off
setlocal

:: 默认参数
set LISTEN=127.0.0.1:1080
set SERVER=
set TOKEN=
set RANDOMIZE=true

:: 检查是否已编译
if not exist "target\release\ech-client-rs.exe" (
    echo ❌ 未找到编译后的文件
    echo 请先运行 build.bat 进行编译
    pause
    exit /b 1
)

:: 简单的参数解析
if "%1"=="" (
    echo ========================================
    echo ECH Tunnel Client - 快速启动
    echo ========================================
    echo.
    set /p SERVER="请输入服务器地址 (例如: worker.workers.dev:443): "
    set /p TOKEN="请输入令牌 (Token): "
    echo.
) else (
    set SERVER=%1
    if not "%2"=="" set TOKEN=%2
)

if "%SERVER%"=="" (
    echo ❌ 错误: 未指定服务器地址
    pause
    exit /b 1
)

echo ========================================
echo 启动参数:
echo ========================================
echo 监听地址: %LISTEN%
echo 服务器: %SERVER%
echo 令牌: %TOKEN%
echo 指纹随机化: %RANDOMIZE%
echo ========================================
echo.

:: 启动客户端
target\release\ech-client-rs.exe ^
    --listen %LISTEN% ^
    --server %SERVER% ^
    --token %TOKEN% ^
    --randomize-fingerprint %RANDOMIZE%

pause
